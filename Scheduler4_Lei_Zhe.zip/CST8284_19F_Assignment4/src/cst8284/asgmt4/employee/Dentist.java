package cst8284.asgmt4.employee;

import java.util.ArrayList;

public class Dentist extends Employee {

	// private static String[] workDescription = {"Assessment", "Filling", "Crown", "Cosmetic Repair"};
	public static ArrayList<String> workDescription = new ArrayList<String>();

	public Dentist(String fullName) {
		super(fullName);
	}

	public  ArrayList<String> getActivityType() {
		workDescription.add("Assessment");
		workDescription.add("Filling");
		workDescription.add("Crown");
		workDescription.add("Cosmetic Repair");

		return workDescription;

	}
}
