package cst8284.asgmt4.scheduler;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

public class OpenApptOp implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {

		String btn = ((JButton) e.getSource()).getActionCommand();
		// https://stackoverflow.com/questions/7867834/get-button-name-from-actionlistener

		if (btn == "Save Appointment") {
			AppointmentDialog.btnPressed = 1;
		} else if (btn == "Display Appointment") {
			AppointmentDialog.btnPressed = 1;
		} else if (btn == "Display Schedule") {
			AppointmentDialog.btnPressed = 2;
		} else if (btn == "Save Appointments to File") {
			AppointmentDialog.btnPressed = 3;
		} else if (btn == "Load Appointments from File") {
			AppointmentDialog.btnPressed = 4;
		}

		if ((AppointmentDialog.btnPressed == 1) || (AppointmentDialog.btnPressed == 2)) {

			AppointmentDialog.showAppointmentDialog();
		} else if (AppointmentDialog.btnPressed == 3) {
			Scheduler.saveAppointmentsToFile(Scheduler.getAppointments(), "CurrentAppointments.apts");
		} else if (AppointmentDialog.btnPressed == 4) {
			Scheduler.loadAppointmentsFromFile("CurrentAppointments.apts", Scheduler.getAppointments());
		}

	}

}
