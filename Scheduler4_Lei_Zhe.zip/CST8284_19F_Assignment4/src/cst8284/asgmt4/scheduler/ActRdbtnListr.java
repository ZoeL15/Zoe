package cst8284.asgmt4.scheduler;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JRadioButton;

public class ActRdbtnListr implements ActionListener {
	//Reference: https://www.codejava.net/java-se/swing/jradiobutton-basic-tutorial-and-examples
	@Override
	public void actionPerformed(ActionEvent e) {
		String jrdbtn = ((JRadioButton) e.getSource()).getActionCommand();

		if (jrdbtn == "Assessment") {
			AppointmentDialog.rdbtnIdx = 0;
		} else if (jrdbtn == "Filling") {
			AppointmentDialog.rdbtnIdx = 1;
		} else if (jrdbtn == "Crown") {
			AppointmentDialog.rdbtnIdx = 2;		
		} else if (jrdbtn == "Cosmetic Repair") {
			AppointmentDialog.rdbtnIdx = 3;
			
		}
	}

}
