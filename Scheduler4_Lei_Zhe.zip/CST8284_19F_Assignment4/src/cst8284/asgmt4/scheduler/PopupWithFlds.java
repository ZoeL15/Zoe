package cst8284.asgmt4.scheduler;

import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PopupWithFlds {

	public static boolean displayPopup() {
		JPanel panel = new JPanel(new GridLayout(0, 1));
		
		JTextField newDate = new JTextField(AppointmentDialog.aptDateField.getText());
		panel.add(new JLabel("Date:"));
		panel.add(newDate);
		
		JTextField newTime = new JTextField(AppointmentDialog.aptTimeField.getText());
		panel.add(new JLabel("Time:"));
		panel.add(newTime);
		
		int result = JOptionPane.showConfirmDialog(null, panel, "Please provide new date or time",
				JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
		if (result == JOptionPane.OK_OPTION) {
			AppointmentDialog.aptDateField.setText(newDate.getText());
			AppointmentDialog.aptTimeField.setText(newTime.getText());
			return true;
		} else {
			JOptionPane.showMessageDialog(null, "Action Cancelled", "Appointment", 0);
			return false;
		}

	}

}
