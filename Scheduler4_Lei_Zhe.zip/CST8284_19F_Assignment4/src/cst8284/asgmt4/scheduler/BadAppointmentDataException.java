package cst8284.asgmt4.scheduler;

public class BadAppointmentDataException extends java.lang.RuntimeException {
	private static final long serialVersionUID = 1L;
	private String Description;

	public BadAppointmentDataException() {
		this("Please try again", "Bad data entered");
	}

	public BadAppointmentDataException(String s1, String s2) {
		super(s1);
		this.setDescription(s2);
	}

	public void setDescription(String s) {
		this.Description = s;
	}

	public String getDescription() {
		return this.Description;
	}

}
