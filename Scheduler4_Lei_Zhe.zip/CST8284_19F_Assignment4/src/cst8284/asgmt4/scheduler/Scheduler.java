package cst8284.asgmt4.scheduler;
//import java.util.Scanner;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

import cst8284.asgmt4.employee.Employee;

//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;

public class Scheduler {

	// private static Scanner scan = new Scanner(System.in);
	private static ArrayList<Appointment> appointments = new ArrayList<>();
	private static Employee employee;
	private static TelephoneNumber phone;
	private static String gfullName;
	private static Activity act;
//	private static final int SAVE_APPOINTMENT = 1, DELETE_APPOINTMENT = 2, CHANGE_APPOINTMENT = 3,
//			DISPLAY_APPOINTMENT = 4, DISPLAY_SCHEDULE = 5, SAVE_APPOINTMENTS_TO_FILE = 6,
//			LOAD_APPOINTMENTS_FROM_FILE = 7, EXIT = 0;

	public Scheduler(Employee emp) {
		// System.out.println("Scheduling appointments for " + emp);
		setEmployee(emp);
	}

	public void setEmployee(Employee emp) {
		this.employee = emp;
	}

	public static Employee getEmployee() {
		return employee;
	}

	public void launch() {
//		int choice = 0;
//		do {
//			choice = displayMenu();
//			executeMenuItem(choice);
//		} while (choice != EXIT);
		SchedulerViewer.launch();

	}

//	private int displayMenu() {
//		System.out.println("Enter a selection from the following menu:");
//		System.out.println(SAVE_APPOINTMENT + ". Save appointment\n" + DELETE_APPOINTMENT + ". Remove appointment\n"
//				+ CHANGE_APPOINTMENT + ". Change appointment\n" + DISPLAY_APPOINTMENT + ". Get appointment\n"
//				+ DISPLAY_SCHEDULE + ". Display schedule\n" + SAVE_APPOINTMENTS_TO_FILE + ". Backup appointments\n"
//				+ LOAD_APPOINTMENTS_FROM_FILE + ". Load appointments\n" + EXIT + ". Exit program");
//		int ch = scan.nextInt();
//		scan.nextLine(); // 'eat' the next line in the buffer
//		System.out.println();
//		return ch;
//	}

//	private void executeMenuItem(int choice) {
//		switch (choice) {
//		case SAVE_APPOINTMENT:
//			saveAppointment(makeAppointmentFromUserInput());
//			this.sortAppointment();
//			break;
//		case DELETE_APPOINTMENT:
//			deleteAppointment(makeCalendarFromUserInput(false));
//			break;
//		case CHANGE_APPOINTMENT:
//			changeAppointment(makeCalendarFromUserInput(false));
//			break;
//		case DISPLAY_APPOINTMENT:
//			displayAppointment(makeCalendarFromUserInput(false));
//			break;
//		case DISPLAY_SCHEDULE:
//			displayDaySchedule(makeCalendarFromUserInput(true));
//			break;
//		case SAVE_APPOINTMENTS_TO_FILE:
//			saveAppointmentsToFile(getAppointments(), "CurrentAppointments.apts");
//			break;
//		case LOAD_APPOINTMENTS_FROM_FILE:
//			loadAppointmentsFromFile("CurrentAppointments.apts", getAppointments());
//			break;
//		case EXIT:
//			System.out.println("Exiting Scheduler\n\n");
//			break;
//		default:
//			System.out.println("Invalid choice: try again. (Select " + EXIT + " to exit.)\n");
//		}
//		System.out.println(); // add blank line after each output
//	}

	// private static String getResponseTo(String s) {
	// System.out.print(s);
	// return (scan.nextLine());
	private static String getResponseTo(JTextField t) {
		return (t.getText());

	}

	// private Appointment makeAppointmentFromUserInput() {

	public static Appointment makeAppointmentFromUserInput() {
		String fullName;
		// do {
		fullName = getResponseTo(AppointmentDialog.fullNameField); // "Enter Client Name (as FirstName LastName): ");
		// } while (!(isNameCorrect(fullName)));

		if (isNameCorrect(fullName)) {

			String phoneNumber;
			// do {
			phoneNumber = getResponseTo(AppointmentDialog.phoneNumField); // "Phone Number (e.g. 613-555-1212): ");

			// } while (!(isPhoneNumberCorrect(phoneNumber)));

			if (isPhoneNumberCorrect(phoneNumber)) {

				TelephoneNumber phone = new TelephoneNumber(phoneNumber);

				Calendar cal = makeCalendarFromUserInput(false);
				if (cal != null) {
					String activity = getResponseTo(AppointmentDialog.descField);// "Enter Activity: ");
					if (!(activity.isEmpty())) {
						
						String actType = getEmployee().getActivityType().get(AppointmentDialog.rdbtnIdx);
						if (!(actType.isEmpty())) {
						Activity act = new Activity(activity, actType);

						return (new Appointment(cal, fullName, phone, act));
						
						} else {return null;} //end of actType.isEmpty()
					} else {return null;} // end of activity.isempty()
				} else { return null; } // end of cal!=null
			} else {return null; } // end of phone correct
		} else { return null;} // end of fullname check

	}// makeAppointmentFromUserInput()

	public static Calendar makeCalendarFromUserInput(boolean suppressHour) {
		Calendar cal = Calendar.getInstance();
		int hour = 0;

		cal.clear();
		String date;
		// do {
		date = getResponseTo(AppointmentDialog.aptDateField);// "Appointment Date (entered as DDMMYYYY): ");
		// } while (!(isCalendarFormatCorrect(date)));

		if (isCalendarFormatCorrect(date)) {

			int day = Integer.parseInt(date.substring(0, 2));
			int month = Integer.parseInt(date.substring(2, 4)) - 1; // offset by one to account for zero-based month in
																	// Calendar
			int year = Integer.parseInt(date.substring(4, 8));

			if (!suppressHour) {
				String time = getResponseTo(AppointmentDialog.aptTimeField); // "Appointment Time: ");
				if (!(time.isEmpty())) {
					hour = processTimeString(time);
				}
			}

			cal.set(year, month, day, hour, 0);
			return (cal);
		} else {
			return null;
		}

	}// end of makeCalendarFromUserInput(boolean suppressHour)

//	private boolean saveAppointment(Appointment apt) {
	public static boolean saveAppointment(Appointment apt) {
		Calendar cal = apt.getCalendar(); // Check that the appointment does not already exist
		if (findAppointment(cal) == null) { // Time slot available, okay to add appointment
			getAppointments().add(apt);
			// System.out.println("Appointment saved.");
			JOptionPane.showMessageDialog(null, "Appointment saved.", "Appointment", 1);
			return true;
		} // else time slot taken, need to make another choice
			// System.out.println("Cannot save; an appointment at that time already
			// exists");
		JOptionPane.showMessageDialog(null, "Cannot save; an appointment at that time already exists", "Appointment",
				0);
		return false;
	}

	private static int processTimeString(String t) {
		int hour = 0;
		t = t.trim();
		if (t.contains(":"))
			hour = Integer.parseInt(t.split(":")[0]);
		else if (t.contains(" "))
			hour = Integer.parseInt(t.split(" ")[0]);
		else
			hour = Integer.parseInt(t);
		return ((hour < 8) ? hour + 12 : hour);
	}

	public static Appointment findAppointment(Calendar cal) {
		sortAppointment();
		ArrayList<Appointment> apt = getAppointments();
		if (apt.isEmpty()) {
			return null;
		} else {
			int index;
			gfullName = "A S";

			TelephoneNumber phone = new TelephoneNumber("613-111-2222");

			String activity = "Cleaning";// "Enter Activity: ");
			Activity act = new Activity(activity, getEmployee().getActivityType().get(AppointmentDialog.rdbtnIdx));

			index = Collections.binarySearch(apt, new Appointment(cal, gfullName, phone, act),
					new SortAppointmentByCalendar());
			if (index >= 0) {
				Appointment rapt = apt.get(index);
				return rapt;
			} else {
				return null;
			}
		} // end of outer else
	}

	public static boolean deleteAppointment(Calendar cal) {
		if (displayAppointment(cal)) { // display existing appointment on this date/time
			// String okToChange = getResponseTo("\nEnter 'Yes' to delete this
			// appointment");
//https://docs.oracle.com/javase/tutorial/uiswing/components/dialog.html
			int result = JOptionPane.showConfirmDialog(null, "Sure? You want to delete?", "Appointment",
					JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

			// if (okToChange.trim().equals("Yes")) { // okay to proceed with
			// change/deletion?
			if (result == JOptionPane.YES_OPTION) {
				// getAppointments().remove(findAppointment(cal));
				getAppointments().remove(getAppointments().indexOf(findAppointment(cal)));

				// System.out.println("Appointment deleted");
				JOptionPane.showMessageDialog(null, "Appointment deleted", "Appointment", 1);
				return true;
			} else
				// System.out.println("Request cancelled");
				JOptionPane.showMessageDialog(null, "Request cancelled", "Appointment", 1);
		}
		return false; // Appointment didn't exist at the date/time specified
	}

	public static boolean changeAppointment(Calendar cal) {
		if (displayAppointment(cal)) { // display existing appointment on this date/time
			// String okToChange = getResponseTo("\nEnter 'Yes' to change the date and time
			// of this appointment ");
			int result = JOptionPane.showConfirmDialog(null,
					"Click 'Yes' to change the date and time of this appointment", "Appointment",
					JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

			// if (okToChange.trim().equals("Yes")) {
			if (result == JOptionPane.YES_OPTION) {
				if (PopupWithFlds.displayPopup()) {

					// System.out.println("Enter new date and time");
					Calendar newCal = makeCalendarFromUserInput(false); // get new date/time
					if (newCal != null) {
						if (findAppointment(newCal) == null) { // appointment time not already taken
							findAppointment(cal).setCalendar(newCal); // set new date/time in appointment
							// System.out.println("Appointment re-booked\n");
							JOptionPane.showMessageDialog(null, "\"Appointment re-booked", "Appointment", 1);
							return true; // new appointment time set
						} else
							// System.out.println("That time is already booked for an appointment\n");
							JOptionPane.showMessageDialog(null, "\"That time is already booked for an appointment",
									"Appointment", 1);

					}
				}

			} else
				// System.out.println("Request cancelled");
				JOptionPane.showMessageDialog(null, "Request cancelled", "Appointment", 1);

		}
		return false; // Appointment does not exist, was unavailable, or cancelled
	}

	public static boolean displayAppointment(Calendar cal) {
		Appointment apt = findAppointment(cal);
		int hr = cal.get(Calendar.HOUR_OF_DAY);
		// System.out.print((apt != null) ? "\n\n" + apt.toString() + "\n" : // Output
		// the appointment as a string to the
		// console, otherwise...
		// "No appointment scheduled between " + hr + ":00 and " + (hr + 1) + ":00\n");

		if (apt != null) {
			SchedulerViewer.getListOfStrings().add(apt.toString() + "\n");
		} else {
			SchedulerViewer.getListOfStrings()
					.add("No appointment scheduled between " + hr + ":00 and " + (hr + 1) + ":00" + "\n");
		}

		return (apt != null);

	}

	public static void displayDaySchedule(Calendar cal) {
		for (int hrCtr = 8; hrCtr < 17; hrCtr++) {
			cal.set(Calendar.HOUR_OF_DAY, hrCtr);
			displayAppointment(cal);
		}
	}

	public static boolean saveAppointmentsToFile(ArrayList<Appointment> apts, String saveFile) {
		String lo_str = "Appointment data saved to " + saveFile;

		int result = JOptionPane.showConfirmDialog(null, "Sure? You want to save appointments to file?", "Appointment",
				JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

		if (result == JOptionPane.YES_OPTION) {

			try (FileOutputStream fos = new FileOutputStream(saveFile);
					ObjectOutputStream oos = new ObjectOutputStream(fos);) {
				for (Appointment apt : apts)
					oos.writeObject(apt);
				// System.out.println("Appointment data saved to " + saveFile);

				JOptionPane.showMessageDialog(null, lo_str, "Appointment", 1);

				return true;
			} catch (IOException e) {
				// System.out.println("Failed to load appointments from " + saveFile);
				lo_str = "Failed to load appointments from " + saveFile;
				JOptionPane.showMessageDialog(null, lo_str, "Appointment", 0);
				return false;
			}
		} else {
			JOptionPane.showMessageDialog(null, "Request cancelled", "Appointment", 1);
			return false;
		}
	}

	public static boolean loadAppointmentsFromFile(String sourceFile, ArrayList<Appointment> apts) {
		String lo_str = "Appointments successfully loaded from " + sourceFile;

		int result = JOptionPane.showConfirmDialog(null, "Sure? You want to load appointments from file?",
				"Appointment", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

		if (result == JOptionPane.YES_OPTION) {

			apts.clear(); // remove all existing appointments from the ArrayList before loading from file
			try (FileInputStream fis = new FileInputStream(sourceFile);
					ObjectInputStream ois = new ObjectInputStream(fis);) {
				while (true)
					apts.add((Appointment) ois.readObject());
			} catch (EOFException ex) {
				// System.out.println("Appointments successfully loaded from " + sourceFile);
				JOptionPane.showMessageDialog(null, lo_str, "Appointment", 1);
				return true;
			} catch (IOException | ClassNotFoundException e) {
				return false;
			}
		} else {
			JOptionPane.showMessageDialog(null, "Request cancelled", "Appointment", 1);
			return false;
		}
	}

	public static ArrayList<Appointment> getAppointments() {

		return appointments;
	}

	private static boolean isPhoneNumberCorrect(String phoneNumber) {
		String lo_str;
		try {

			notNull(phoneNumber);

			String[] strArray = phoneNumber.split(""); // convert String to String array

			if (strArray[0].matches("1") || strArray[0].matches("0")) {
				throw new BadAppointmentDataException("Area code can't start with a '0' or '1'", "");
			} else {
				for (int i = 0; i < strArray.length; i++) {
					if (strArray[i].matches("-")) {
					} else if (strArray[i].matches("[0-9]+")) {

					} // end of else
					else {

						throw new BadAppointmentDataException(
								"Telephone number can only contain numbers or the character'-' ", "");
					}
				} // end of for loop
			} // end of else

			if ((strArray.length) != 12) {

				throw new BadAppointmentDataException("Missing digit(s);",
						"correct format is AAA-PPP-NNNN, where AAA is the area code and PPP-NNNN is the local number");

			}
			return true;
		} // end of try
		catch (BadAppointmentDataException ex) {
			// System.out.println(ex.getMessage() + "; please re-enter\n");
			lo_str = ex.getMessage() + "; please re-enter";
			JOptionPane.showMessageDialog(null, lo_str, "Appointment", 1);
			return false;
		}

	} // end of method

	private static boolean isNameCorrect(String fullName) {
		String lo_str;
		try {

			notNull(fullName);

			String[] strArray = fullName.split("");
			int len = strArray.length;

			for (int i = 0; i < len; i++) {
				if (strArray[i].matches("[a-zA-Z.]+") || strArray[i].matches("-") || strArray[i].matches("'")
						|| strArray[i].matches(" ")) {

				} else {
					throw new BadAppointmentDataException(
							"Name cannot include characters other than alphabetic characters,\nthe dash(-), the period(.), and the apostrophe(')",
							"");
				} // end of else

			} // end of for loop

			if (len > 30) {
				throw new BadAppointmentDataException("Name cannot exceed 30 characters", "");
			} else {
				return true;
			}
		} // end of try
		catch (BadAppointmentDataException ex) {
			// System.out.println(ex.getMessage() + "; please re-enter\n");
			lo_str = ex.getMessage() + "; please re-enter";
			JOptionPane.showMessageDialog(null, lo_str, "Appointment", 1);
			return false;

		}
	}// end of method

	private static boolean isCalendarFormatCorrect(String date1) {
		String lv_str;
		try {
			try {
				notNull(date1);
//source:https://stackoverflow.com/questions/18480633/java-util-date-format-conversion-yyyy-mm-dd-to-mm-dd-yyyy
				SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
				sdf.setLenient(false);
				sdf.parse(date1);
			} // end of inner try

			catch (ParseException e) {
				throw new BadAppointmentDataException("Bad calendar date entered; format is DDMMYYYY", "");
			} // end of outer try
		} catch (BadAppointmentDataException ex) {
			// System.out.println(ex.getMessage() + "; please re-enter\n");
			lv_str = ex.getMessage() + ";" + ex.getDescription();
			JOptionPane.showMessageDialog(null, lv_str, "Appointment", 1);
			return false;
		}
		return true;

	}// end of method

	private static boolean notNull(String val) {
		if (val != null && val.length() > 0 && !val.trim().isEmpty()) {
			return true;
		} else {
			throw new BadAppointmentDataException("Must enter a value", "");
		}

	}// end of notNull

	private static void sortAppointment() {
		ArrayList<Appointment> apt = getAppointments();
		if (!(apt.isEmpty())) {
			Collections.sort(apt, new SortAppointmentByCalendar());
		}
	}

//	/**
//	 * getter method of global phone variable, used in collection binary search method
//	 * @return {@code gphone} object for binary search of appointments
//	 */
//	public static TelephoneNumber getGphone() {
//		return gphone;
//	}

//	/**
//	 * setter method of global phone variable, used in collection binary search method
//	 * @param gphone TelephoneNumber object input by user
//	 */
//	public static void setGphone(TelephoneNumber gphone) {
//		gphone = gphone;
//	}

//	/**
//	 * this getter method of global fullName variable, used in collection binary search method
//	 * @return gfullName for binary search operation
//	 */
//	public static String getGfullName() {
//		return gfullName;
//	}

//	/**
//	 * {@code setGfullName} setter method of global gfullName variable, used in collection binary search method
//	 * @param gfullName use for the binary search.
//	 */
//	public static void setGfullName(String gfullName) {
//		
//		gfullName = gfullName;
//	}

//	/**
//	 * }{@code getGact} getter method of global object gact variable, used in collection binary search method
//	 * @return Activity global object used in binary search
//	 */
//	public static Activity getGact() {
//		return gact;
//	}

//	/**
//	 * {@code setGact} setter method of global gact object variable, used in collection binary search method
//	 * @param gact Activity object to be used in binary search
//	 */
//	public static void setGact(Activity gact) {
//		gact = gact;
//	}

}// end of class
