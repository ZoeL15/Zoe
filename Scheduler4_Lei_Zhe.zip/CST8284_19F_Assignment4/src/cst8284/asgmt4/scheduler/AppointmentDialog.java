package cst8284.asgmt4.scheduler;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Calendar;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;

/* Adapted, with considerable modification, from 
 * http://www.java2s.com/Code/Java/Swing-JFC/TextAcceleratorExample.htm,
 * which is sloppy code and should not be emulated.
 */

public class AppointmentDialog {

	public static JTextField fullNameField;
	public static JTextField phoneNumField;
	public static JTextField aptDateField;
	public static JTextField aptTimeField;
	public static JTextField descField;

	private static final GridBagConstraints textConstants = new GridBagConstraints(0, GridBagConstraints.RELATIVE, 1, 1,
			1, 1, // gridx, gridy, gridwidth, gridheight, weightx, weighty
			GridBagConstraints.EAST, 0, new Insets(2, 2, 2, 2), 1, 1); // anchor, fill, insets, ipadx, ipady
	private static final GridBagConstraints labelConstants = new GridBagConstraints(1, GridBagConstraints.RELATIVE, 1,
			1, 1.0, 0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(2, 2, 2, 2), 0, 0);

	public static GridBagConstraints btnConstants = new GridBagConstraints();

	private static Container cp;
	private static final int labelWidth = 35;
	private static final Font defaultFont = new Font("SansSerif", Font.PLAIN, 16);
	private static final Toolkit tk = Toolkit.getDefaultToolkit();
	private static final Dimension screenSize = tk.getScreenSize();
	public static int btnPressed;
	public static int rdbtnIdx;

	public static void showAppointmentDialog() {

		int screenX = (int) screenSize.getWidth() / 2;
		int screenY = (int) (screenSize.getHeight() / 3);

		JFrame f = new JFrame("Get, set, change or delete an appointment");
		cp = f.getContentPane();
		cp.setLayout(new GridBagLayout());

		f.setPreferredSize(new Dimension(screenX, screenY));
        f.setLocation(230, 230); //to show second dialog box little down the first dialog box
		fullNameField = setRow("Enter Client Name (as FirstName LastName):", 'n');
		phoneNumField = setRow("Phone Number (e.g. 613-555-1212):", 'p');
		aptDateField = setRow("Appointment Date (entered as DDMMYYYY):", 'd');
		aptTimeField = setRow("Appointment Time:", 't');
		descField = setRow("Activity Description", 'a');

		JLabel label; // = new JLabel();
		cp.add(label = new JLabel("Activity Category", SwingConstants.RIGHT), textConstants);
        
		createActbtn(); // create action button
		createRdbtn(); // create activity radiobtn

		f.pack();
		f.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent evt) {
				f.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			}
		});
		f.setVisible(true);
	}

	private static JTextField setRow(String label, char keyboardShortcut) {
		JLabel l;
		JTextField t;
		cp.add(l = new JLabel(label, SwingConstants.RIGHT), textConstants);
		l.setFont(defaultFont);
		l.setDisplayedMnemonic(keyboardShortcut);
		cp.add(t = new JTextField(labelWidth), labelConstants);
		t.setFocusAccelerator(keyboardShortcut);
		return t;
	}

	private static void createActbtn() {

		actBtnListr actbtnlistner = new actBtnListr();

		JButton GetBtn = new JButton("Get");
		GetBtn.addActionListener(actbtnlistner);
		cp.add(GetBtn, btnConstants);

		JButton SetBtn = new JButton("Set");
		SetBtn.addActionListener(actbtnlistner);
		cp.add(SetBtn, btnConstants);

		JButton ChgBtn = new JButton("Change");
		ChgBtn.addActionListener(actbtnlistner);
		cp.add(ChgBtn, btnConstants);

		JButton DelBtn = new JButton("Delete");
		DelBtn.addActionListener(actbtnlistner);
		cp.add(DelBtn, btnConstants);
			
	}// createActbtn

	private static void createRdbtn() {
		// ArrayList<String> actList = new ArrayList<>();
		ArrayList<String> actList = Scheduler.getEmployee().getActivityType();
		ActRdbtnListr actRd = new ActRdbtnListr();
		// https://www.codejava.net/java-se/swing/jradiobutton-basic-tutorial-and-examples
		if (!(actList.isEmpty())) {
			JRadioButton option1 = new JRadioButton(actList.get(0));
			JRadioButton option2 = new JRadioButton(actList.get(1));
			JRadioButton option3 = new JRadioButton(actList.get(2));
			JRadioButton option4 = new JRadioButton(actList.get(3));

			ButtonGroup group = new ButtonGroup();
			group.add(option1);
			group.add(option2);
			group.add(option3);
			group.add(option4);

			option1.addActionListener(actRd);
			option2.addActionListener(actRd);
			option3.addActionListener(actRd);
			option4.addActionListener(actRd);

			cp.add(option1, labelConstants);
			cp.add(option2, labelConstants);
			cp.add(option3, labelConstants);
			cp.add(option4, labelConstants);
		}
	}// end of method createRdbtn()

}
