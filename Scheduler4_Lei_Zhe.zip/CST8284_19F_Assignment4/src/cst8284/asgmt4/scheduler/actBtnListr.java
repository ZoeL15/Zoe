package cst8284.asgmt4.scheduler;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;

import javax.swing.JButton;

public class actBtnListr implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {
		//Reference: https://stackoverflow.com/questions/7867834/get-button-name-from-actionlistener
		String btn = ((JButton) e.getSource()).getActionCommand();

		if (btn == "Get") {
			SchedulerViewer.getListOfStrings().clear();
			Calendar cal = Scheduler.makeCalendarFromUserInput(false);
			
			if ( (AppointmentDialog.btnPressed == 1) && (cal!=null)) { //save appointment
					Scheduler.displayAppointment(cal);
					SchedulerViewer.reloadJTextArea();
				
			} else if ((AppointmentDialog.btnPressed == 2) && (cal!=null)) { //display schedule

					Scheduler.displayDaySchedule(cal);
					SchedulerViewer.reloadJTextArea();
				
			}

		} else if (btn == "Set") {//save appointment
			SchedulerViewer.getListOfStrings().clear();
			Appointment apt = Scheduler.makeAppointmentFromUserInput();
			if (apt!=null) {
				Scheduler.saveAppointment(apt); 
			}
		
		} else if (btn == "Change") {//change appointment			
				Calendar cal = Scheduler.makeCalendarFromUserInput(false);
				if (cal!=null) {
				Scheduler.changeAppointment(cal); 
				}
		
		} else if (btn == "Delete") {//delete appointment
			SchedulerViewer.getListOfStrings().clear();
			Calendar cal = Scheduler.makeCalendarFromUserInput(false);
			if (cal!=null) {
				Scheduler.deleteAppointment(cal);
			}
		
		} 

	}

}
