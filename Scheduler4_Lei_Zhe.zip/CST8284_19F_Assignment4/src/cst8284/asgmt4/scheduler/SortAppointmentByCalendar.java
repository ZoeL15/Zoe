package cst8284.asgmt4.scheduler;
import java.util.Comparator;

import cst8284.asgmt4.scheduler.Appointment;

public class SortAppointmentByCalendar implements Comparator<Appointment>{

@Override
	public int compare(Appointment apt1, Appointment apt2){
		return (int) (apt1.getCalendar().getTimeInMillis() - apt2.getCalendar().getTimeInMillis());
	
	}
	

	
	
}
