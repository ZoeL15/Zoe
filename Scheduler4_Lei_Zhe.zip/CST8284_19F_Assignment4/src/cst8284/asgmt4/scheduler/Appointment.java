package cst8284.asgmt4.scheduler;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Appointment implements Serializable {
	private static final long serialVersionUID = 1L;
	private Calendar aptDate;
	private String firstName, lastName;
	private TelephoneNumber phone;
	private Activity activity;

	public Appointment(Calendar cal, String fullName, TelephoneNumber phone, Activity act) {
		this(cal, fullName.trim().split(" ")[0], fullName.trim().split(" ")[1], phone, act);
	}
	
	public Appointment(Calendar cal, String firstName, String lastName, TelephoneNumber phone, Activity act) {
		setFirstName(firstName.trim()); 
		setLastName(lastName.trim());
		setCalendar(cal); 
		setPhone(phone);
		setActivity(act);
	}

	public Calendar getCalendar() {return aptDate;}

	public void setCalendar(Calendar aptDate) {this.aptDate = aptDate;}

	public String getFirstName() {return firstName; }

	public void setFirstName(String firstName) {this.firstName = firstName;}

	public String getLastName() {return lastName;}

	public void setLastName(String lastName) {this.lastName = lastName;}

	public TelephoneNumber getPhone() {return phone;}

	public void setPhone(TelephoneNumber phone) {this.phone = phone;}

	public Activity getActivity() {return activity;}

	public void setActivity(Activity activity) {this.activity = activity;}
	
	public String toString() {
		SimpleDateFormat formatDate = new SimpleDateFormat("E MMM dd yyyy HH:mm");
		String lo_FullTime = formatDate.format(this.getCalendar().getTime());	
		return lo_FullTime.toString() + "\n" +
			   getFirstName() + " " + getLastName() + "\n" + 
			   getPhone().toString() + "\n" +
			   getActivity().toString();
	}

}
