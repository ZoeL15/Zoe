/* Course Name: CST 8284-Object Oriented Programming (Java)
Student Name: Lei, Zhe
Class name:CST8284-Section300; Lab Section: 304
Date: Oct 22th, 2019
*/
package cst8284.asgmt2.scheduler;

import java.util.Scanner;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.NotSerializableException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import cst8284.asgmt2.employee.Employee;

import java.util.ArrayList;
import java.util.Calendar;

/**This assignment use the sample code of Assignment 1.
 * This assignment refer to Hybrid 4 & 5 from Prof. Dave Houtman.
 */
public class Scheduler {
	
	private static Scanner scan = new Scanner(System.in);
	private ArrayList<Appointment> appointments = new ArrayList<>();//create arrayList
	private Employee employee;  
	
	private static final int SAVE_APPOINTMENT = 1;
	private static final int DELETE_APPOINTMENT = 2;
	private static final int CHANGE_APPOINTMENT = 3;
	private static final int DISPLAY_APPOINTMENT = 4;
	private static final int DISPLAY_SCHEDULE = 5;
	private static final int SAVE_APPOINTMENTS_TO_FILE = 6;
	private static final int LOAD_APPOINTMENTS_FROM_FILE = 7;
	private static final int EXIT = 0;
	
	public Scheduler(Employee emp) {
		setEmployee(emp);
	}
	
	public void launch() {
		int choice = 0;
		do {
		   choice = displayMenu();
		   executeMenuItem(choice);
		} while (choice != EXIT);		
	}
	
	public void setEmployee(Employee emp) {
		this.employee = emp;
	}
	
	public Employee getEmployee() {
		return employee;
	}
	
	private int displayMenu() {
		System.out.println("Enter a selection from the following menu: ");
		System.out.println(
			SAVE_APPOINTMENT + ". Save appointment\n" +
			DELETE_APPOINTMENT + ". Delete appointment\n" +
			CHANGE_APPOINTMENT + ". Change appointment\n" +
			DISPLAY_APPOINTMENT  + ". Get appointment\n" +
			DISPLAY_SCHEDULE + ". Display schedule\n" +
			SAVE_APPOINTMENTS_TO_FILE + ". Save appointsment to file\n" +
			LOAD_APPOINTMENTS_FROM_FILE + ". Load appointsment to file\n" +
			EXIT + ". Exit program");
		int ch = scan.nextInt();
		scan.nextLine();  // 'eat' the next line in the buffer
		System.out.println();
		return ch;
	}
	
	private void executeMenuItem(int choice) {
		switch (choice) {
			case SAVE_APPOINTMENT: 
				saveAppointment(makeAppointmentFromUserInput()); 
				break;
			case DELETE_APPOINTMENT: 
				deleteAppointment(makeCalendarFromUserInput(false)); 
				break;
			case CHANGE_APPOINTMENT: 
				changeAppointment(makeCalendarFromUserInput(false)); 
				break;
			case DISPLAY_APPOINTMENT: 
				displayAppointment(makeCalendarFromUserInput(false));
				break;
			case DISPLAY_SCHEDULE: 
				displayDaySchedule(makeCalendarFromUserInput(true)); 
				break;
			case SAVE_APPOINTMENTS_TO_FILE: 
				saveAppointmentsToFile(getAppointments(), "CurrentAppointments.apts"); 
				break;
			case LOAD_APPOINTMENTS_FROM_FILE: 
				loadAppointmentsFromFile(getAppointments(), "CurrentAppointments.apts"); 
				break;
			case EXIT: 
				System.out.println("Exiting Scheduler\n\n"); 
				break;
			default: System.out.println("Invalid choice: try again. (Select " + EXIT + " to exit.)\n");
		}
		System.out.println();  // add blank line after each output
	}
	
	private boolean saveAppointment(Appointment apt) {	
		Calendar cal = apt.getCalendar();  // Check that the appointment does not already exist
		if (findAppointment(cal)==null) {  // Time slot available, okay to add appointment
			getAppointments().add(apt); // add new appointments to arrayList
			System.out.println("Appointment saved.");  
			return true;
		}  // else time slot taken, need to make another choice
		System.out.println("Cannot save; an appointment at that time already exists");
		return false;
	}
	
	private boolean deleteAppointment(Calendar cal) {
		for (Appointment apt1: appointments) {
			if (apt1 == findAppointment(cal)) {
				displayAppointment(cal); // display the appointments by calling displayAppointment()
				System.out.println("Enter 'Yes' to delete this appointment: ");
				String answer = scan.nextLine();
//				scan.nextLine();
				if (answer.equals("Yes")) {
					getAppointments().remove(apt1);// finds the appointment and delete from apts
					System.out.println("Appointment deleted.");
					return true;
				}
			}
		}
		System.out.println("Cannot delete.");// if can't find the appointment or doesn't want to delete, print this message
		return false;
	}
	
	private boolean changeAppointment(Calendar cal) {
		for (Appointment apts: appointments) {
			if (apts == findAppointment(cal)) {// search for the appointment in arrayList
				displayAppointment(cal);// display the appointment if found
				System.out.println("Enter 'Yes' to change the date and time of this appointment: ");
				String ans = scan.nextLine();
				if (ans.equals("Yes")) {
					System.out.println("Enter new date and time");//promt user for new date and time
					Calendar newCal = makeCalendarFromUserInput(false);//create new Calendar newCal
					if (findAppointment(newCal) == null) {
						apts.setCalendar(newCal);// user setter to set the new date and time of the appointment
						System.out.println("Appointment re-booked");
						return true;
					}else {
						System.out.println("Appointment alreay exists, please enter a new time:");
						return false;
					}					
				}
			}
		}
		System.out.println("Cannot change the appointment");
		return false;
	}
	
	private void displayAppointment(Calendar cal) {
		Appointment apt = findAppointment(cal);
		int hr = cal.get(Calendar.HOUR_OF_DAY);
		System.out.println((apt!=null) ?
		   "\n"+ apt.toString()+"\n": // Output the appointment as a string to the console, otherwise...
  	       "No appointment scheduled between "+ hr + ":00 and " + (hr + 1) + ":00"
		);
	}
	
	private void displayDaySchedule(Calendar cal) {
		for (int hrCtr = 8; hrCtr < 17; hrCtr++) {
			cal.set(Calendar.HOUR_OF_DAY, hrCtr);
			displayAppointment(cal);		
		}
	}
	
	/*This method is refer to Hybrid 4 and 5, from Dave Houtman*/
	private static boolean saveAppointmentsToFile(ArrayList<Appointment> apts, String saveFile){
		try (	
			FileOutputStream fos = new FileOutputStream(saveFile);//instantiate a new FileOuputStream object
			ObjectOutputStream oos = new ObjectOutputStream(fos);//instantiate a new ObjectOutputStream object
			){	
				for (Appointment thisApt: apts) {//enhanced for loop to loop thru the apts arrayList
					oos.writeObject(thisApt); //write the appointment to file
				}
				System.out.println("Appointment data saved to CurrentAppointments.apts");
				return true;	
			}
			catch(FileNotFoundException ex) {//if file not exist, print out the error message
				System.out.println("File not found: check the path for file: " + saveFile);
			}
			catch (NotSerializableException nex) {
				nex.printStackTrace();
			}
			catch(IOException ex) {
				ex.printStackTrace();
				System.out.println(ex.toString());
			}
		return false;
	}
	
	/*This method is refer to Hybrid 4 and 5, from Dave Houtman*/
	private static boolean loadAppointmentsFromFile(ArrayList<Appointment> apts, String sourceFile){
		Object apt;// declare a local variable Object apt;
		try(
			FileInputStream fin = new FileInputStream(sourceFile);//instantiate a new FileIuputStream object
			ObjectInputStream ois = new ObjectInputStream(fin);//instantiate a new ObjectIuputStream object
			){
				while(true){
					if (fin.available() != 0) {//loop thru all object in the file
						apt = ois.readObject();//assign the value of each object to variable apt
						apts.add((Appointment)apt);// cast the object to Appointment and save to apts arrayList
					}else
						break;
				}
				System.out.println("Appointments successfully loaded from CurrentAppointments.apts");
				return true;
			} catch (FileNotFoundException e) {
				//e.printStackTrace();
				
			} catch (EOFException ex) {
				ex.printStackTrace();
			}
			catch (IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				System.out.println("File not found");
				//e.printStackTrace();
			}
		return false;
		}
	
    private static String getResponseTo(String s) {
    	System.out.print(s);
		return(scan.nextLine());
    }
	
    private Appointment makeAppointmentFromUserInput() {
    	String fullName = getResponseTo("Enter Client Name (as FirstName LastName): ");
		String phoneNumber = getResponseTo("Phone Number (e.g. 613-555-1212): ");
		TelephoneNumber phone = new TelephoneNumber(phoneNumber);
		Calendar cal = makeCalendarFromUserInput(false);
		String activity = getResponseTo("Enter Activity: ");
		Activity act = new Activity(activity, getEmployee().getActivityType());
		return (new Appointment(cal, fullName, phone, act));
    }
    
    private static Calendar makeCalendarFromUserInput(boolean suppressHour) {
    	Calendar cal = Calendar.getInstance();
    	int hour = 0;
    	
    	cal.clear();
		String date = getResponseTo("Appointment Date (entered as DDMMYYYY): ");
		int day = Integer.parseInt(date.substring(0,2));
		int month = Integer.parseInt(date.substring(2,4))-1;  // offset by one to account for zero-based month in Calendar
		int year = Integer.parseInt(date.substring(4,8));
		
		if (!suppressHour) {				
		   String time = getResponseTo("Appointment Time: ");
		   hour = processTimeString(time);
		}

		cal.set(year, month, day, hour, 0);
		return (cal);
    }
    
	private static int processTimeString(String t) {
		int hour = 0;
		t = t.trim();
		if (t.contains(":")) hour = Integer.parseInt(t.split(":")[0]);
		else if (t.contains (" ")) hour = Integer.parseInt(t.split(" ")[0]);
		else hour = Integer.parseInt(t);
		return ((hour < 8) ? hour+12 : hour);
	}
	
    private Appointment findAppointment(Calendar cal) {
    	for (Appointment apt: appointments) 
    		if(cal.equals(apt.getCalendar())) 
    			return apt;		
    	return null;
    }
	
    // return an arrayList appointments
	private ArrayList<Appointment> getAppointments() {
		return appointments;
	}

	     
}
