/* Course Name: CST 8284-Object Oriented Programming (Java)
Student Name: Lei, Zhe
Class name:CST8284-Section300; Lab Section: 304
Date: Oct 22th, 2019
*/
package cst8284.asgmt2.scheduler;

import cst8284.asgmt2.employee.Dentist;

public class SchedulerLauncher {

	public static void main(String[] args) {
		System.out.println("Scheduling appointments for " + new Dentist("Dr.Andrews").toString());
		(new Scheduler(new Dentist("Dr.Andrews"))).launch();
		
	}
}
