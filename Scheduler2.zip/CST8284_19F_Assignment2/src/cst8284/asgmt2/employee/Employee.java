/* Course Name: CST 8284-Object Oriented Programming (Java)
Student Name: Lei, Zhe
Class name:CST8284-Section300; Lab Section: 304
Date: Oct 22th, 2019
*/
package cst8284.asgmt2.employee;

import java.io.Serializable;
import java.util.Scanner;

public abstract class Employee implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String fullName;
	
	protected Employee() {this("unknown");}
	protected Employee(String fullName) {setName(fullName);}
	protected static Scanner scan = new Scanner(System.in);
	
	public void setName(String fullName) {this.fullName = fullName;}
	public String getName() {return fullName;}
	
	public abstract String getActivityType();
	
	@Override
	public String toString() {return getName();}
	
}