/* Course Name: CST 8284-Object Oriented Programming (Java)
Student Name: Lei, Zhe
Class name:CST8284-Section300; Lab Section: 304
Date: Oct 22th, 2019
*/
package cst8284.asgmt2.employee;



public class Dentist extends Employee{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Dentist(String fullName) {
		super.setName(fullName);
	}

	@Override
	public String getActivityType() {
		String activityType = null;
		System.out.println("Enter a category from the following menu:");
		System.out.println(
			1 + ". Assessment\n" +
			2  + ". Filling\n" +
			3 + ". Crown\n" +
			4 + ". Cosmetic Repairs");
		int choice = scan.nextInt();
		scan.nextLine();  // 'eat' the next line in the buffer
		System.out.println();
		
		switch (choice) {
		case 1: 
			activityType = "Assessment";
			break;
		case 2: 
			activityType = "Filling";
			break;
		case 3: 
			activityType = "Crown";
			break;
		case 4: 
			activityType = "Cosmetic Repairs"; 
			break;
		default: System.out.println("Invalid choice: try again.\n");
	}
		return activityType;
	}

}
