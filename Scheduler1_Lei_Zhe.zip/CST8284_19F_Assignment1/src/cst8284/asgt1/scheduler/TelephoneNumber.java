/* Course Name: CST 8284-Object Oriented Programming (Java)
Student Name: Lei, Zhe
Class name:CST8284-Section300; Lab Section: 304
Date: Sep 27th, 2019
*/
package cst8284.asgt1.scheduler;

public class TelephoneNumber {
	private int areaCode;
	private int prefix;
	private int lineNumber;
	
	//constructor
	public TelephoneNumber(String phoneNumber) {
		areaCode = Integer.parseInt((phoneNumber.split("-"))[0]);
		prefix = Integer.parseInt((phoneNumber.split("-"))[1]);
		lineNumber = Integer.parseInt((phoneNumber.split("-"))[2]);
	}
	
	// getter 
	public int getAreaCode() {
		return areaCode;
	}
	
	//setter
	public void setAreaCode(int areaCode) {
		this.areaCode = areaCode;
	}
	
	// getter 
	public int getPrefix() {
		return prefix;
	}
	
	//setter
	public void setPrefix(int prefix) {
		this.prefix = prefix;
	}
	
	// getter 
	public int getLineNumber() {
		return lineNumber;
	}
	
	//setter
	public void setLineNumber(int lineNumber) {
		this.lineNumber= lineNumber;
	}
	
	//toString method
		public String toString() {
			return "("+ getAreaCode() +")" + getPrefix() + "-" + getLineNumber();
		}

}
