/* Course Name: CST 8284-Object Oriented Programming (Java)
Student Name: Lei, Zhe
Class name:CST8284-Section300; Lab Section: 304
Date: Sep 27th, 2019
*/
package cst8284.asgt1.scheduler;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Appointment {
	private Calendar aptDate;
	private String firstName;
	private String lastName;
	private TelephoneNumber phone;
	private Activity activity;
	/*SimpleDateFormate reference: http://docs.oracle.com*/
	SimpleDateFormat f = new SimpleDateFormat("EEE MMM dd yyyy HH:00");

	// constructor
	/* Calendar class reference: https://www.geeksforgeeks.org/calendar-class-injava-with-examples/*/
	public Appointment(Calendar cal, String fullName, TelephoneNumber phone, Activity activity) {
		this(cal, fullName.split(" ")[0], fullName.split(" ")[1], phone, activity);
	}

	// constructor
	public Appointment(Calendar cal, String firstName, String lastName, TelephoneNumber phone, Activity activity) {
		this.aptDate = cal;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.activity = activity;
	}

	// getter getaptDate
	public Calendar getAptDate() {
		return aptDate;
	}

	// setter setaptDate
	public void setAptDate(Calendar aptDate) {
		this.aptDate = aptDate;
	}

	// getter getFirstName
	public String getFirstName() {
		return firstName;
	}

	// setter getFirstName
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	// getter getlastName
	public String getLastName() {
		return lastName;
	}

	// setter setlastName
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	// getter getPhone
	public TelephoneNumber getPhoneNumber() {
		return phone;
	}

	// setter setPhone
	public void setPhoneNumber(TelephoneNumber phone) {
		this.phone = phone;
	}

	// getter getActivity
	public Activity getActivity() {
		return activity;
	}

	// setter setActivity
	public void setActivity(Activity activity) {
		this.activity = activity;
	}

	// toString method
	public String toString() {
		return f.format(getAptDate().getTime()) + "\n" + getFirstName().toString() + " " + getLastName().toString() + "\n"
				+ getPhoneNumber().toString() + "\n" + getActivity().toString();
	}
}
