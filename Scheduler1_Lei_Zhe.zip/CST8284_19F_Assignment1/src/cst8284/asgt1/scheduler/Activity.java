/* Course Name: CST 8284-Object Oriented Programming (Java)
Student Name: Lei, Zhe
Class name:CST8284-Section300; Lab Section: 304
Date: Sep 27th, 2019
*/
package cst8284.asgt1.scheduler;

public class Activity {
	private String descriptionOfWork;
	private String category;
	
	//constructor
	public Activity(String description, String category) {
		this.descriptionOfWork = description;
		this.category = category;
	}
	
	// getter 
	public String getDescription() {
		return descriptionOfWork;
	}
	
	//setter
	public void setDescription(String descriptionOfWork) {
		this.descriptionOfWork = descriptionOfWork;
	}
	
	// getter 
	public String getCategory() {
		return category;
	}
	
	//setter
	public void setCategory(String category) {
		this.category = category;
	}
	
	//toString method
	public String toString() {
		return getDescription() + " " + getCategory();
	}
}
