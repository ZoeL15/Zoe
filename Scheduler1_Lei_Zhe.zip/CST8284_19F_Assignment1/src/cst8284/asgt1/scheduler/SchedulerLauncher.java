/* Course Name: CST 8284-Object Oriented Programming (Java)
Student Name: Lei, Zhe
Class name:CST8284-Section300; Lab Section: 304
Date: Sep 27th, 2019
*/
package cst8284.asgt1.scheduler;

public class SchedulerLauncher {

	public static void main(String[] args) {
		Scheduler s1 = new Scheduler();
		s1.launch();

	}

}
