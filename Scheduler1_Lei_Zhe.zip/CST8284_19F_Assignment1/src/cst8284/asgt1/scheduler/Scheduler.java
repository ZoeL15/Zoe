/* Course Name: CST 8284-Object Oriented Programming (Java)
Student Name: Lei, Zhe
Class name:CST8284-Section300; Lab Section: 304
Date: Sep 27th, 2019 */
package cst8284.asgt1.scheduler;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;

public class Scheduler {
	private static Scanner scan;
	private Appointment[] appointments;
	private int aptIndex;
	private static final int SAVE_APPOINTMENT = 1, DISPLAY_APPOINTMENT = 2, DISPLAY_SCHEDULE = 3, EXIT = 0; //create constant varible
	SimpleDateFormat format = new SimpleDateFormat("EEE MMM dd yyyy HH:00"); // format the date output 

	// Scheduler Constructor
	public Scheduler() {
		scan = new Scanner(System.in);
		appointments = new Appointment[200];
	}

	// public launch method
	public void launch() {
		int option = 0;
		do {
			option = displayMenu();
			executeMenuItem(option);
		} while (option != 0);

	}

	// displayMenu method
	/* I learn this format from CST8284-Fall 2019 Lab3 */
	private int displayMenu() {
		// display menu and return an interger value
		System.out.printf("%s\n\t%s\n\t%s\n\t%s\n\t%s", "Enter a selection from the following menu:",
				SAVE_APPOINTMENT + ". Save appointment", DISPLAY_APPOINTMENT + ". Display appointment",
				DISPLAY_SCHEDULE + ". Display schedule", EXIT + ". Exit program" + "\n");
		return (scan.nextInt());
	}

	// executeMenuItem method
	/* I learn this format from CST8284-Fall 2019 Lab3 */
	private void executeMenuItem(int choice) {
		// switch case to execute menu item
		scan.nextLine(); // Remove CRLF from input buffer
		switch (choice) {
		case 1:
			if (saveAppointmentToArray(makeAppointmentFromUserInput())) {
				System.out.println("Appointment Saved");
				aptIndex++;
			} else {
				System.out.println("Cannot save; an appointment at that time already exists");
			}
			System.out.println();
			break;
		case 2:
			displayAppointment(makeCalendarFromUserInput(false));
			System.out.println();
			break;
		case 3:
			displayDaySchedule(makeCalendarFromUserInput(true));
			System.out.println();
			break;
		case 0:
			System.out.println("Exit Scheduler");
			break;
		default:
			System.out.println("Unknown operation requested");
			System.out.println();
		}
	}

	// saveAppointmentToArray method
	private boolean saveAppointmentToArray(Appointment apt) {
		for (int i = 0; i < appointments.length; i++)
			if (findAppointment(apt.getAptDate()) == null) {
				appointments[aptIndex] = apt;
				return true;
			}
		return false;
	}

	// private displayAppointment method
	/* I learn Calendar class from https://www.geeksforgeeks.org/calendar-class-injava-with-examples */
	private void displayAppointment(Calendar cal) {
		if (findAppointment(cal) != null) {
			System.out.println(findAppointment(cal).toString());
		} else {
			System.out.println("No appointment scheduled between " + cal.get(Calendar.HOUR_OF_DAY) + ":00" + " and "
					+ (cal.get(Calendar.HOUR_OF_DAY) + 1) + ":00"); //HOUR_OF_DAY is 24h clock
		}
	}

	// private displayDaySchedule method
	private void displayDaySchedule(Calendar cal) {
		//initialize a variable h for the hour from 8am to 4pm, loop thru the hour to find matching appointment
		int h;
		for (h = 8; h <= 16; h++) {
			cal.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DATE), h, 0, 0);
			if (findAppointment(cal) != null) {
				System.out.println("\n" + (findAppointment(cal).toString()) + "\n");
			} else {
				System.out.println("No appointment scheduled between " + h + ":00" + " and " + (h + 1) + ":00");
			}
		}
	}

	// getResponseTo method
	private static String getResponseTo(String s) {
		System.out.println(s);
		return (scan.nextLine());
	}

	// makeAppointmentFromUserInput method
	private static Appointment makeAppointmentFromUserInput() {
		// scan.nextLine();
		String fullName = Scheduler.getResponseTo("Enter Client Name (as FirstName LastName):");
		// scan.nextLine();
		String phone = getResponseTo("Phone Number (e.g. 613-555-1212):");
		Calendar cal = makeCalendarFromUserInput(false);
		String activity = getResponseTo("Enter Activity:");
		return new Appointment(cal, fullName, new TelephoneNumber(phone), new Activity(activity, " "));
	}

	// private makeCalendarFromUserInput method
	private static Calendar makeCalendarFromUserInput(boolean suppressHour) {
		// create a String variable s1 to store user response to get appointment date
		String s1 = getResponseTo("Appointment Date (entered as DDMMYYYY):");
		Calendar cal = Calendar.getInstance();// instantiate a new Calendar Object
		cal.clear();
		// create variable to store time values
		int month, day, year, hour;
		day = Integer.parseInt(s1.substring(0, 2));
		month = Integer.parseInt(s1.substring(2, 4));
		year = Integer.parseInt(s1.substring(4, 8));

		// check conditons if suppressHour is false, call getResponseTo() another time
		// to get appointment time
		if (suppressHour == false) {
			String s2 = getResponseTo("Appointment Time:");
			hour = processTimeString(s2); // call processTimeString method to process hour
			cal.set(year, month - 1, day, hour, 0);
			return cal;
			// if suppressHour is true, do not need to get appointment time
		} else {
			hour = 0;
			cal.set(year, month - 1, day, 0, 0);
			return cal;
		}
	}

	// processTimeString method
	/* SubString(), endsWith(), trim() I learn how to use them from https://www.geeksforgeeks.org/substring-in-java/*/
	private static int processTimeString(String t) {
		// create an integer variable time
		int time;

		// check condition if time String t ends with p.m. or pm, use subString() method
		// to remove p.m. or pm
		if (t.endsWith("p.m.") || t.endsWith("pm")) {
			t = t.substring(0, t.indexOf("p")).trim();
			// check condition time String t ends with a.m. or am, use subString() method to
		} else if (t.endsWith(".") || t.endsWith("am")) {// remove a.m. or am
			t = t.substring(0, t.indexOf("a")).trim();
		}
		// check condition time String t ends with :00, use subString() method to remove :00
		if (t.indexOf(":") > 0) {
			t = t.substring(0, t.indexOf(":"));
		}
		time = Integer.parseInt(t);// parse string to int
		// check condition if time < 4, that means clent enter time in the afternoon,
		if (time <= 4) {
			time += 12;// add 12 to time to indicate afternoon time
		}
		return time;
	}

	// findAppintment method
	private Appointment findAppointment(Calendar cal) {
		// loop thru the appointments array to find the matching appointment by
		// comparing the appointment date with cal
		int i;
		for (i = 0; i < getAptIndex(); i++)
			if (getAppointments()[i] != null) {
				if (getAppointments()[i].getAptDate().equals(cal))
					return getAppointments()[i];
			}
		return null;
	}

	// getAppointments(): Appointment[]
	private Appointment[] getAppointments() {
		return appointments;
	}

	// getAptIndex(){
	private int getAptIndex() {
		return aptIndex;
	}

	// getNextAptIndex method
	private int getNextAptIndex() {
		return aptIndex++;
	}
}
