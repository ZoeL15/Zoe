<!DOCTYPE html>
<html>
    <?php include 'header.php' ?>
            <div id="content" class="clearfix">
                <h1>Coming Soon!</h1>
            </div><!-- End Content -->
            <?php include 'footer.php' ?>
        </div><!-- End Wrapper -->
    </body>
</html>
