package cst8284.asgmt3.employee;

import java.util.Scanner;

/**
 * <p>Employee</p>
 * This class is an abstract class, can be extended to Dentist subclass
 * @author Zhe Lei
 * @version 1.0
 */
public abstract class Employee {
	/**
	 * employee's fullName
	 */
	private String fullName;
	
	/**
	 * Employee no arg constructor
	 */
	protected Employee() {this("unknown");}
	
	/**
	 * Employee 1 argument constructor
	 * @param fullName String
	 */
	protected Employee(String fullName) {setName(fullName);}
	
	protected static Scanner scan = new Scanner(System.in);
	
	/**
	 * This method take a String fullName as parameter, set this fullName to String fullName parameter
	 * @param fullName String
	 */
	public void setName(String fullName) {this.fullName = fullName;}
	
	/**
	 * This method returns String fullName
	 * @return fullName String
	 */
	public String getName() {return fullName;}
	
	/**
	 * This abstract method can be extended in subclass used to return a String activityType
	 * @return String activityType
	 */
	public abstract String getActivityType();
	
	@Override
	public String toString() {return getName();}
}