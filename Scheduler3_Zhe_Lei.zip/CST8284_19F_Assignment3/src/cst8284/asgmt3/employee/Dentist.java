package cst8284.asgmt3.employee;

/**
 * <p>Dentist</p>
 * This Dentist class extends superclass Employee
 * This class can be used to instantiate a Dentist object
 * @author Zhe Lei
 * @version 1.0
 */
public class Dentist extends Employee {
	/**
	 * String array to store workDescriptions
	 */
	private static String[] workDescription = {"Assessment", "Filling", "Crown", "Cosmetic Repair"};

	/**
	 * Dentist constructor
	 * @param fullName String
	 */
	public Dentist(String fullName) {
		super (fullName);
	}

	/**
	 * Override getActivityType method
	 * This method display an activity type menu and prompt user to choose a description from the menu
	 * @return String description
	 */
	public String getActivityType() {
		System.out.println("Enter a selection from the following menu:");
		int i = 1;
		for (String description: workDescription)
			System.out.println(i++ + "." + description);
		int ch = scan.nextInt();
		scan.nextLine(); // 'eat' the next line in the buffer
		System.out.println();  // add a space
		return workDescription[ch-1];
	}
}
