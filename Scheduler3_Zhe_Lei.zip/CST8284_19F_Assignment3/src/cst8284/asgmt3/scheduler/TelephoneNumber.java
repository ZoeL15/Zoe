package cst8284.asgmt3.scheduler;

import java.io.Serializable;

/**
 * <p>TelephoneNumber</p>
 * This class implements Serializable, create Telephone number object
 * @author Zhe Lei
 * @version 1.0
 *
 */
public class TelephoneNumber implements Serializable {
	/**
	 * Default serial version ID
	 */
	private static final long serialVersionUID = 1L;
	private int areaCode, lineNumber, prefix;
	
	/**
	 * TelephoneNumber constructor, take a String phoneNumber as parameter
	 * @throws BadAppointmentDataException if phoneNumber is not not in correct format
	 * @param phoneNumber String
	 */
	public TelephoneNumber(String phoneNumber) {
		if (phoneNumber == null || phoneNumber.isEmpty() == true) { // check if String phoneNumber is empty or null or not
			throw new BadAppointmentDataException("Empty or null value entered", "Must enter a value");
		}
		if (phoneNumber.length() != 12 || phoneNumber.charAt(3) != '-' || phoneNumber.charAt(7) != '-') { // check if phoneNumber is missing digits or in correct format or not,
			throw new BadAppointmentDataException("Missing digit(s); correct format is AAA-PPP-NNNN, where AAA is the area code and PPP-NNNN is the local number",
					"Incorrect format");
		}

		if (phoneNumber.startsWith("0") || phoneNumber.startsWith("1")) { // check if phoneNumber areaCode is start with 0 or 1 or not
			throw new BadAppointmentDataException("Area code can't start with a '0' or '1'", "Invalid number");
		}
		String specialCharacters = " !#$%&'()*+,./:;<=>?@[]^_`{|}~";
		for (int i = 0; i < specialCharacters.length(); i++) { // check if phoneNumber contains specialCharacters 
			if (phoneNumber.contains(String.valueOf(specialCharacters.charAt(i))) == true) {
				throw new BadAppointmentDataException("Telephone numbers can only contain numbers or the character '-'", "Bad character(s) in input string");
			}
		}
		int areaCode = Integer.parseInt(phoneNumber.split("-")[0].trim()); // split phoneNumber String to get areaCode
		int prefix = Integer.parseInt(phoneNumber.split("-")[1].trim());// split phoneNumber String to get prefix
		int lineNumber = Integer.parseInt(phoneNumber.split("-")[2].trim());// split phoneNumber String to get lineNumber
		setAreaCode(areaCode); setPrefix(prefix); setLineNumber(lineNumber);
	}	
	
	/**
	 * This getter return areaCode
	 * @return int areaCode
	 */
	public int getAreaCode() {return areaCode;}
	
	/**
	 * This setter method take an integer parameter, set areaCode to this integer value
	 * @param areaCode Integer
	 */
	public void setAreaCode(int areaCode) {this.areaCode = areaCode;}
	
	/**
	 * This getter returns an Integer prefix
	 * @return int prefix
	 */
	public int getPrefix() { return prefix;}
	
	/**
	 * This setter take an integer parameter, set prefix to this integer value
	 * @param prefix Integer
	 */
	public void setPrefix(int prefix) {this.prefix = prefix;}
	
	/**
	 * This getter method returns an Integer lineNumber
	 * @return lineNumber integer
	 */
	public int getLineNumber() {return lineNumber;}
	
	/**
	 * This setter take an Integer lineNumbr as parameter, set lineNumber to this integer value
	 * @param lineNumber Integer
	 */
	public void setLineNumber(int lineNumber) {this.lineNumber = lineNumber;}
	
	/**
	 * This method return "(" + getAreaCode() +") "+ getPrefix() + "-" + getLineNumber();
	 */
	public String toString() {return "(" + getAreaCode() +") "+ getPrefix() + "-" + getLineNumber();}
}
