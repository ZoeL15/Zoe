package cst8284.asgmt3.scheduler;

import cst8284.asgmt3.employee.Dentist;

/**
 * <h1>SchedulerLauncher</h1>
 * This class contains main method to launch Scheduler program
 * @author Zhe Lei
 * @version 1.0
 */
public class SchedulerLauncher {

	/**
	 * launch Scheduler class
	 * @param args String[]
	 */
	public static void main(String[] args) {
		(new Scheduler(new Dentist("Dr. Andrews"))).launch();
	}
}
