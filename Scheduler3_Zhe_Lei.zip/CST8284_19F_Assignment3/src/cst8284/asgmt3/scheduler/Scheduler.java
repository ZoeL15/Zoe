package cst8284.asgmt3.scheduler;

import java.util.Scanner;

import cst8284.asgmt3.employee.Employee;

import java.io.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;

/**
 *  @author  Zhe Lei
 *  @version version 1.0
 */
public class Scheduler {

	private static Scanner scan = new Scanner(System.in);
	/**
	 * new Appointment type ArrayList object appointments
	 */
	private ArrayList<Appointment> appointments = new ArrayList<>();
	/**
	 * class variable, the name of employee, Employee type object employee
	 */
	private Employee employee;


	/**
	 * integer value of SAVE_APPOINTMENT
	 */
	private static final int SAVE_APPOINTMENT =            1;    
	   /**
	    * integer value of DELETE_APPOINTMENT
	    */
	private static final int  DELETE_APPOINTMENT =            2;
	   /**
	    * integer value of CHANGE_APPOINTMENT
	    */
	private static final int CHANGE_APPOINTMENT =          3; 
	   /**
	    * integer value of DISPLAY_APPOINTMENT
	    */
	private static final int  DISPLAY_APPOINTMENT =           4;
	   /**
	    * integer value of DISPLAY_SCHEDULE
	    */
	private static final int DISPLAY_SCHEDULE =            5;  
	   /**
	    * integer value of SAVE_APPOINTMENTS_TO_FILE
	    */
	private static final int SAVE_APPOINTMENTS_TO_FILE =     6;
	   /**
	    * integer value of LOAD_APPOINTMENTS_FROM_FILE
	    */
	private static final int LOAD_APPOINTMENTS_FROM_FILE = 7;    
	   /**
	    * integer value of EXIT
	    */
	private static final int EXIT =                          0;
	   
	/**
	 * Scheduler constructor, create a Scheduler object
	 * @param emp the Employee object
	 */
	public Scheduler(Employee emp) {
		System.out.println("Scheduling appointments for " + emp);
		setEmployee(emp);
	}
	
	/**
	 * set an Employee object employee
	 * @param emp this Employee object
	 */
	private void setEmployee(Employee emp) {this.employee = emp;}
	
	/**
	 * Employee getter
	 * @return Employee object employee
	 */
	private Employee getEmployee() {return employee;}
	
	/**
	 * while choice is not equal to EXIT, launch the Scheduler program
	 */
	public void launch() {
		int choice = 0;
		do {
		   choice = displayMenu();
		   executeMenuItem(choice);
		} while (choice != EXIT);		
	}
	
	/**
	 * display a menu for user to choose from, return the user's choice
	 * @return ch an Integer value from user input
	 */
	private int displayMenu() {
		System.out.println("Enter a selection from the following menu:");
		System.out.println(
			SAVE_APPOINTMENT + ". Save appointment\n" +
			DELETE_APPOINTMENT + ". Remove appointment\n" +
			CHANGE_APPOINTMENT + ". Change appointment\n" +
			DISPLAY_APPOINTMENT  + ". Get appointment\n" +
			DISPLAY_SCHEDULE + ". Display schedule\n" +
			SAVE_APPOINTMENTS_TO_FILE + ". Backup appointments\n" +
			LOAD_APPOINTMENTS_FROM_FILE + ". Load appointments\n" +
			EXIT + ". Exit program");
		int ch = scan.nextInt();
		scan.nextLine();  // 'eat' the next line in the buffer
		System.out.println();
		return ch;
	}
	
	/**
	 * use switch case to execute different menu items based on the Integer value of choice
	 * @param choice the choice from user input 
	 */
	private void executeMenuItem(int choice) {
		switch (choice) {
			case SAVE_APPOINTMENT: 
				saveAppointment(makeAppointmentFromUserInput()); 
				break;
			case DELETE_APPOINTMENT:
				deleteAppointment(makeCalendarFromUserInput(false));
				break;
			case CHANGE_APPOINTMENT:
				changeAppointment(makeCalendarFromUserInput(false));
				break;
			case DISPLAY_APPOINTMENT: 
				displayAppointment(makeCalendarFromUserInput(false));
				break;
			case DISPLAY_SCHEDULE: 
				displayDaySchedule(makeCalendarFromUserInput(true)); 
				break;
			case SAVE_APPOINTMENTS_TO_FILE:
				saveAppointmentsToFile(getAppointments(), "CurrentAppointments.apts");
				break;
			case LOAD_APPOINTMENTS_FROM_FILE:
				loadAppointmentsFromFile("CurrentAppointments.apts", getAppointments());
				break;
			case EXIT: 
				System.out.println("Exiting Scheduler\n\n"); 
				break;
			default: 
				System.out.println("Invalid choice: try again. (Select " + EXIT + " to exit.)\n");
		}
		System.out.println();  // add blank line after each output
	}
	
	/**
	 * use getResponseTo() method to ask user for input and get the response from user
	 * @param s String pass to getResponseTo method 
	 * @return scan.nextLine()
	 */
    private static String getResponseTo(String s) {
    	System.out.print(s);
		return(scan.nextLine());
    }
	
    /**
     * This method allows user input, return an Appointment object using the information from user input
     * @return new Appointment object
     * @exception BadAppointmentDataException if fullName, firstName, lastName, Calendar, phoneNumber input not correct
     */
    private Appointment makeAppointmentFromUserInput() {
    	boolean isInputOk = false;
    	Appointment apt1 = null;
    	do {
	    	try {
	    		String fullName = getResponseTo("Enter Client Name (as FirstName LastName): ");
		    		if (fullName == null || fullName.isEmpty()) {
		    			throw new BadAppointmentDataException("FirstName must enter a value", "Empty or null value entered");
		    		}
		    		if (!fullName.contains(" ")) {
		    			throw new BadAppointmentDataException("LastName must enter a value", "Empty or null value entered");
		    		}
	    		String phoneNumber = getResponseTo("Phone Number (e.g. 613-555-1212): ");
	    		TelephoneNumber phone = new TelephoneNumber(phoneNumber);
	    		Calendar cal = makeCalendarFromUserInput(false);
	    		String activity = getResponseTo("Enter Activity: ");
	    		Activity act = new Activity(activity, getEmployee().getActivityType());
	    		apt1 = new Appointment(cal, fullName, phone, act);
	    		isInputOk = true;
	    	
	    	} catch (BadAppointmentDataException ex) {
	    		System.out.println(ex.getMessage() + " ; " + ex.getDescription() + "\n");
	    	} catch (Exception ex) {
	    		System.out.println("General exception thrown; source unknown");
	    	}
	    	
    	} while (isInputOk == false);
    	
    	return apt1;
    }
    
    /**
     * This method takes user input for Calendar date information and time information depends on the boolean value of suppressHour
     * if suppressHour is true, prompt user for date input, don't need user input for time
     * if suppressHour is false, prompt user for both input for date and time
     * @param suppressHour boolean value 
     * @return Calendar object cal
     */
    private static Calendar makeCalendarFromUserInput(boolean suppressHour) {
    	Calendar cal = Calendar.getInstance();
    	int hour = 0;
    	DateFormat dateFormat = new SimpleDateFormat("ddMMyyyy");
		dateFormat.setLenient(false);
		
    	cal.clear();
		String date = getResponseTo("Appointment Date (entered as DDMMYYYY): ");
		if (date.isEmpty() == true || date == null) {
			throw new BadAppointmentDataException("Must enter a value", "Empty or null value entered");
		}
		
		try {
			dateFormat.parse(date);
		} catch (BadAppointmentDataException ex) {
			ex.setDescription("Bad Calendar formart; format is DDMMYYYY");
		} catch (ParseException e) {
			throw new BadAppointmentDataException("Bad Calendar formart; format is DDMMYYYY", "Bad calendar format");
			
		}

		int day = Integer.parseInt(date.substring(0,2));
		int month = Integer.parseInt(date.substring(2,4)) - 1;  // offset by one to account for zero-based month in Calendar
		int year = Integer.parseInt(date.substring(4,8));
		
		if (!suppressHour) {				
		   String time = getResponseTo("Appointment Time: ");
		   hour = processTimeString(time);
		}

		cal.set(year, month, day, hour, 0);
		return (cal);
    }
    
    /**
     * This method takes a time String t, process time String to integer
     * @param t time String
     * @return Integer value of this time String
     */
	private static int processTimeString(String t) {
		int hour = 0;
		t = t.trim();
		if (t.contains(":")) hour = Integer.parseInt(t.split(":")[0]);
		else if (t.contains (" ")) hour = Integer.parseInt(t.split(" ")[0]);
		else hour = Integer.parseInt(t);
		return ((hour < 8) ? hour+12 : hour);
	}
	
    	/**
    	 *  create a SortAppointmentByCalendar object
    	 *  use SortAppointmentByCalendar object to sort Appointments arrayList using the Collections sort() method
    	 *  use Collections binarySearch() method to find an Appointment element in the arrayList
    	 *  return an Appointment object or null, depends on whether or not the Appointment exist in the arrayList or not
    	 *  Reference: https://www.geeksforgeeks.org/collections-binarysearch-java-examples/
    	 *  <p>
    	 *  @param cal an Calendar object
    	 *  @return    the Appointment with the specific Calendar object or null
    	 */
	 	private Appointment findAppointment(Calendar cal) {
    	Comparator<Appointment> sortAptByCalObj = new SortAppointmentByCalendar();
    	Collections.sort(getAppointments(), sortAptByCalObj);
    	int index = Collections.binarySearch(getAppointments(), new Appointment(cal, "n", "n", new TelephoneNumber("200-000-0000"), new Activity("n", "n")), sortAptByCalObj);
    	return (index < 0 )? null : getAppointments().get(index);
    }
    
	 	/**
	 	 * This method take an appointment object apt as parameter
	 	 * use findAppointment()method to search if this Appointment object exist in the Appointments arrayList or not
	 	 * if this Appointment object exist in the arrayList, return false
	 	 * if this Appointment object does not exist in the arrayList, add this Appointment object to arrayList
	 	 * @param apt Appointment object apt
	 	 * @return boolean value 
	 	 */
	private boolean saveAppointment(Appointment apt) {	
		Calendar cal = apt.getCalendar();  // Check that the appointment does not already exist
		if (findAppointment(cal)==null) {  // Time slot available, okay to add appointment
			getAppointments().add(apt);
			System.out.println("Appointment saved.");  
			return true;
		}  // else time slot taken, need to make another choice
		System.out.println("Cannot save; an appointment at that time already exists");
		return false;
	}
	
	/**
	 * This method take a Calendar object cal as parameter, search for Appointment in Appointment arrayList
	 * If displayAppointment(cal) returns true, prompt user to enter Yes to delete this appointment
	 * If user input Yes, remove the Appointment from Appointment arrayList, return true
	 * If the Appointment not exists at the date/time specified, or user input is not Yes, return false
	 * @param cal Calendar object
	 * @return boolean value
	 */
	private boolean deleteAppointment(Calendar cal) {
		if (displayAppointment(cal)) {  							// display existing appointment on this date/time
			String okToChange = getResponseTo("\nEnter 'Yes' to delete this appointment");
			if (okToChange.trim().equals("Yes")) {  						// okay to proceed with change/deletion?
				getAppointments().remove(findAppointment(cal)); 
				System.out.println("Appointment deleted"); 
				return true;
			} else System.out.println("Request cancelled"); 
		} return false;  // Appointment didn't exist at the date/time specified
	}
	
	/**
	 * This method take a Calendar object cal as parameter, search for Appointment with this cal
	 * If displayAppointment returns true, prompt user to enter Yes to change this appointment
	 * If user input Yes, prompt user for input for date and time, set the new Calendar for this Appointment object
	 * return true if successfully change the Appointment, return false if appointment does not exist or user cancel this change
	 * @param cal Calendar object 
	 * @return boolean value
	 */
	private boolean changeAppointment(Calendar cal) {
		if (displayAppointment(cal)) {  							// display existing appointment on this date/time
  		    String okToChange = getResponseTo("\nEnter 'Yes' to change the date and time of this appointment ");
			if (okToChange.trim().equals("Yes")) { 
				System.out.println("Enter new date and time");
				Calendar newCal = makeCalendarFromUserInput(false); // get new date/time
				if (findAppointment(newCal)==null) {				// appointment time not already taken
					findAppointment(cal).setCalendar(newCal);		// set new date/time in appointment
					System.out.println("Appointment re-booked\n");
					return true;									// new appointment time set
				} else System.out.println("That time is already booked for an appointment\n");
			} else System.out.println("Request cancelled"); 
		} return false;  // Appointment does not exist, was unavailable, or cancelled
	}
	
	/**
	 * This method take a Calendar object cal as parameter, search for Appointment object with this Calendar date and time in Appointment arrayList
	 * If this Appointment exist in the arrayList, display this appointment, return true
	 * If this appointment does not exist in the arrayList, return false
	 * @param cal Calendar object
	 * @return boolean value
	 */
	private boolean displayAppointment(Calendar cal) {
		Appointment apt = findAppointment(cal);
		int hr = cal.get(Calendar.HOUR_OF_DAY);
		System.out.print((apt!=null) ?
		   "\n\n"+ apt.toString()+"\n": // Output the appointment as a string to the console, otherwise...
  	       "No appointment scheduled between "+ hr + ":00 and " + (hr + 1) + ":00\n"
		);
		return (apt!=null);
	}
	
	/**
	 * This method take a Calendar object cal as parameter, search for Appointment objects with this Calendar date in Appointment arrayList
	 * If this Appointment exist in the arrayList, display Appointments, return true
	 * If this appointment does not exist in the arrayList, return false
	 * @param cal Calendar object
	 */
	private void displayDaySchedule(Calendar cal) {
		for (int hrCtr = 8; hrCtr < 17; hrCtr++) {
			cal.set(Calendar.HOUR_OF_DAY, hrCtr);
			displayAppointment(cal);		
		}
	}
	
	/**
	 * This method take a String saveFile, an ArrayList apts as parameters, load the Appointment ArrayList from file
	 * If Appointment ArrayList successfully saved to file, return true, or return false
	 * @param apts Appointment ArrayList
	 * @param saveFile String name of file
	 * @return boolean value
	 */
	private static boolean saveAppointmentsToFile(ArrayList<Appointment> apts, String saveFile) {
		try (FileOutputStream fos = new FileOutputStream(saveFile);
			 ObjectOutputStream oos = new ObjectOutputStream(fos);) {
			for (Appointment apt: apts) 
				oos.writeObject(apt);
			System.out.println("Appointment data saved to " + saveFile);
			return true;
		} catch (IOException e) {
			System.out.println("Failed to load appointments from " + saveFile);
			return false;
		}
	}
	
	/**
	 * This method take a String sourceFile, an ArrayList apts as parameters, load the Appointment ArrayList from file
	 * If Appointment objects successfully loaded from file, return true; if not, return false
	 * @param sourceFile String, name of the sourceFile
	 * @param apts ArrayList
	 * @return boolean value
	 */
	private static boolean loadAppointmentsFromFile(String sourceFile, ArrayList<Appointment> apts) {
		apts.clear();  // remove all existing appointments from the ArrayList before loading from file
		try (FileInputStream fis = new FileInputStream(sourceFile);
		     ObjectInputStream ois = new ObjectInputStream(fis);){
		        while(true) apts.add((Appointment)ois.readObject());
		} 
		catch (EOFException ex) {
			System.out.println("Appointments successfully loaded from " + sourceFile);
			return true;}
		catch (IOException | ClassNotFoundException e) {return false;} 	
	}
	
	/**
	 * Gets the appointments arrayList
	 * @return ArrayList appointments
	 */
	private ArrayList<Appointment> getAppointments() {return appointments;}
	     
}
