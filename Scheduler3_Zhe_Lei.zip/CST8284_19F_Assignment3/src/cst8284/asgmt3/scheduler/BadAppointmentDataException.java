package cst8284.asgmt3.scheduler;

/**
 * <p>BadAppointmentDataException</p>
 * This class is to define BadAppointmentDataException extends RuntimeException
 * This class has two contractors
 * @author Zhe Lei
 * @version 1.0
 *
 */
public class BadAppointmentDataException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	static String Desciption;
	
	/**
	 * BadAppointmentDataException constructor
	 * Overload constructor
	 */
	public BadAppointmentDataException() {
		this("Please try again", "Bad data entered");
	}
	
	/**
	 * BadAppointmentDataException 2 argument constructor
	 * @param s1 String
	 * @param s2 String
	 */
	public BadAppointmentDataException(String s1, String s2) {
		super(s1);
		setDescription(s2);
	}
	
	/**
	 * This method take a String Description as parameter, set this Description to this parameter
	 * @param Description String
	 */
	public void setDescription(String Description) {
		this.Desciption = Description;
	}
	
	/**
	 * This method return String Description
	 * @return Description String
	 */
	public String getDescription() {
		return Desciption;
	}
}
