package cst8284.asgmt3.scheduler;

import java.io.Serializable;
import java.util.Calendar;

/**
 * <p>Appointment</p>
 * Appointment class is used to create Appointment object. 
 * An Appointment object contains Calendar object aptDate, String firstName, String lastName, TelephoneNumber phone, Activity activity
 * @author Zhe Lei
 * @version 1.0
 */
public class Appointment implements Serializable {
	/**
	 * A serial version identifier
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Calendar type aptDate, describe date and time of an Appointment
	 */
	private Calendar aptDate;
	/**
	 * String firstName, lastName describe customer's name
	 */
	private String firstName, lastName;
	/**
	 * TelephoneNumber type phone describe customer's phone number
	 */
	private TelephoneNumber phone;
	/**
	 * Activity type activity describe customer's Appointment activity detail
	 */
	private Activity activity;
	
	/**
	 * Appointment 4 parameter constructor
	 * @param cal Calendar
	 * @param fullName String
	 * @param phone TelephoneNumber
	 * @param act Activity
	 */
	public Appointment(Calendar cal, String fullName, TelephoneNumber phone, Activity act) {
		this(cal, fullName.trim().split(" ")[0], fullName.trim().split(" ")[1], phone, act);
	}
	
	/**
	 * Appointment 5 parameter constructor
	 * @param cal Calendar
	 * @param firstName String
	 * @param lastName String
	 * @param phone TelephoneNumber
	 * @param act Activity
	 */
	public Appointment(Calendar cal, String firstName, String lastName, TelephoneNumber phone, Activity act) {
		setFirstName(firstName.trim()); 
		setLastName(lastName.trim());
		setCalendar(cal); 
		setPhone(phone);
		setActivity(act);
	}
	
	/**
	 * This method return Calendar aptDate
	 * @return Calendar aptDate
	 */
	public Calendar getCalendar() {return aptDate;}
	
	/**
	 * This method take a Calendar aptDate as parameter, set this Calendar aptDate to the String parameter
	 * @param aptDate Calendar
	 */
	public void setCalendar(Calendar aptDate) {this.aptDate = aptDate;}
	
	/**
	 * This method return String firstName
	 * @return String firstName
	 */
	public String getFirstName() {return firstName; }
	
	/**
	 * This method take a String firstName as parameter, set this firstName to the String parameter
	 * @param firstName String
	 * @throws BadAppointmentDataException if firstName is null, or firstName exceed 30 characters, or firstName contains special characters
	 */
	public void setFirstName(String firstName) {
		if (firstName.isEmpty() || firstName == null) {// check if firstName is null or is empty
			throw new BadAppointmentDataException("Must enter a value", "Empty or null value entered");
		}
		if (firstName.length() > 30) { // check if firstName exceed 30 characters
			throw new BadAppointmentDataException("Name cannot exceed 30 characters", "Name exceeds maximum length");
		}
		if (firstName.matches("[a-zA-Z-.']+") == false) { // check if firstName contains special characters other than - . '
			throw new BadAppointmentDataException("Name cannot include characters other than alphabetic characters, "
					+ "the dash(-), the period(.), and the apostrophe(')", "Illegal characters in name");
		}
		this.firstName = firstName;
	}
	
	/**
	 * This method returns lastName
	 * @return String lastName
	 */
	public String getLastName() {return lastName;}
	
	/**
	 * This method take a String lastName as parameter, set this lastName to the String parameter
	 * @param lastName String
	 * @throws BadAppointmentDataException if lastName is null, exceed 30 characters, or contains special characters
	 */
	public void setLastName(String lastName) {// check if firstName is null or is empty
		if (lastName.isEmpty() || lastName == null) {
			throw new BadAppointmentDataException("Must enter a value", "Empty or null value entered");
		}
		if (lastName.length() > 30) { // check if firstName exceed 30 characters
			throw new BadAppointmentDataException("Name cannot exceed 30 characters", "Name exceeds maximum length");
		}
		if (lastName.matches("[a-zA-Z-.']+") == false) { // check if firstName contains special characters other than - . '
			throw new BadAppointmentDataException("Name cannot include characters other than alphabetic characters, "
					+ "the dash(-), the period(.), and the apostrophe(')", "Illegal characters in name");
		}
		this.lastName = lastName;
		}
	
	/**
	 * This method return TelephoneNumber phone
	 * @return phone TelephoneNumber
	 */
	public TelephoneNumber getPhone() {return phone;}
	
	/**
	 * This method take a TelephoneNumber phone as parameter, set this phone to the TelephoneNumber phone
	 * @param phone TelephoneNumber
	 */
	public void setPhone(TelephoneNumber phone) {this.phone = phone;}
	
	/**
	 * This method return Activity activity
	 * @return activity Activity 
	 */
	public Activity getActivity() {return activity;}
	
	/**
	 * This method take an Activity activity as parameter, set this activity to activity
	 * @param activity Activity
	 */
	public void setActivity(Activity activity) {this.activity = activity;}
	
	/**
	 * override toString method
	 */
	public String toString() {
		return getCalendar().getTime().toString() + "\n" +
			   getFirstName() + " " + getLastName() + "\n" + 
			   getPhone().toString() + "\n" +
			   getActivity().toString();
	}

}
