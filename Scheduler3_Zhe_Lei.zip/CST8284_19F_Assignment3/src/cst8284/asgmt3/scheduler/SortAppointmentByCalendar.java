package cst8284.asgmt3.scheduler;

import java.util.Comparator;

/**
 * <p>SortAppointmentByCalendar</p>
 * This class implements comparator
 * This class define how to sort Appointments by it's calendar, the object of this class can be used to sort Appointment ArrayList
 * Reference from https://howtodoinjava.com/sort/sort-arraylist-objects-comparable-comparator/
 * @author Zhe Lei
 * @version 1.0
 *
 */
public class SortAppointmentByCalendar implements Comparator<Appointment>{
	/**
	 * This compare method takes two appointment objects as parameter
	 * This method compares the Appointment object's calendar's time value
	 * @return integer value of the difference between two Appointment object's calendar's time value
	 */
	public int compare(Appointment apt1, Appointment apt2) {
		return (int) (apt1.getCalendar().getTimeInMillis() - apt2.getCalendar().getTimeInMillis());
	}

}
