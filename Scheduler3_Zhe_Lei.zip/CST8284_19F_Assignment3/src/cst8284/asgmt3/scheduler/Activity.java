package cst8284.asgmt3.scheduler;

import java.io.Serializable;

/**
 * <p>Activity</p>
 * Activity class is used to create Activity object
 * @author Zhe Lei
 * @version 1.0
 */
public class Activity implements Serializable {
	/**
	 * Defalut Serial Version ID
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * String descriptionOfWork to describe activity
	 */
	private String descriptionOfWork;
	/**
	 * String category describe activity type
	 */
	private String category;
	
	/**
	 * Activity Constructor, take two String parameters, the first String pass to setDescription(), the second string pass to setCategory()
	 * the constructor is used to create an Activity Object with description and category
	 * @param description String
	 * @param category String
	 */
	public Activity(String description, String category) {
		setDescription(description);
		setCategory(category);
	}
	
	/**
	 * This method return a String descriptionOfWork
	 * @return String descriptionOfWork
	 */
	public String getDescription() {return descriptionOfWork;}
	
	/**
	 * This method take a String parameter, set descriptionOfWork to this string
	 * @param description String
	 */
	public void setDescription(String description) {this.descriptionOfWork = description;}
	
	/**
	 * this method returns a String category
	 * @return String category
	 */
	public String getCategory() {return category;}
	
	/**
	 * this method take a String parameter category, set category to this String
	 * @param category String
	 */
	public void setCategory(String category) {this.category = category;}
	
	/**
	 * This method returns getCategory() + "\n" + getDescription()
	 */
	public String toString() {return getCategory() + "\n" + getDescription();}
}
